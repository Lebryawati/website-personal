document.addEventListener("DOMContentLoaded", () => {
  console.log("Website Desa Wisata Tondok Banga' siap!");
});